RegisterCommand("adminalert", function(source, args)
    TriggerServerEvent("adminalert", table.concat(args, " "))
end)

RegisterNetEvent("no-perms")
AddEventHandler("no-perms", function()
    TriggerEvent("chatMessage", "[Error]", {255,0,0}, "Sorry, but you don't have permission to do this" )
end)

Citizen.CreateThread(function()

    TriggerEvent('chat:addSuggestion', '/adminalert', 'Sends a adminalert to all players in chat', {})

end)