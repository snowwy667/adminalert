RegisterServerEvent("adminalert")
AddEventHandler("adminalert", function(param)
    if IsPlayerAceAllowed(source, "adminalert") then
        print("^7[^1AdminAlert^7]^5:" .. param)
        TriggerClientEvent("chatMessage", -1, "^7[^1AdminAlert^7]^2", {0,0,0}, param)
    else 
        TriggerClientEvent("no-perms", source)
    end
end)