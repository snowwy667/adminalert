Adminalert --- Create by Snowwy

================================================

-- How to set staff permissions

1. Open your server.cfg.

2. Add this line "add_ace (your ace permissions staff group) adminalert allow.

3. Save and enjoy!

=================================================

-- How to use

Simply, in chat type /adminalert (the message you wish to put in the announcement), then press enter and all done, the announcement is sent to all
players and in the chat to view.

=================================================

-- Terms of use

DO NOT redistribute this script without my permission.

DO NOT edit this script to repost and take credit.

You MAY use this in your FiveM server or the compatible game.